###this script contains functions for crude permutation test for two groups

#'generate permutated samples: x is oberserved data, n is sample size, nperm is number of permutated samples
permutation_two_crude = function(x, n, nperm)
{
  res=array(0, c(nperm, n))
  
  for( i in 1:nperm)
  {
    res[i,] = sample(x, size=n)
  }
  
  return(res)
}

crude_permutation_test2 = function(x, n1, thres, N=1e6, seed=1, FUN=mean_diff, ...)
{
  n=length(x)
  n2=n-n1
  
  #generate permutated samples
  z = permutation_two_crude(x, n, nperm=N)
  
  #calculate the permutated statistic T(z) based on permutated samples z
  T_stat = FUN(z, n1, ...)
  
  return( sum(T_stat>=thres)/N )
}
  
#if number of permutation is very large, need to divide by subgroups; otherwise run out of memory
crude_permutation_test2_large = function(x, n1, thres, N, seed=1, FUN=mean_diff, ...)
{
  n=length(x)
  n2=n-n1
  
  T_stat = NULL
  niter = N/1e5
  N_bigger=0
  
  set.seed(seed)
  
  for(i in 1:niter)
  {
    #generate 1e6 permutated samples
    z = permutation_two_crude(x, n, nperm=1e5)
  
    #calculate the permutated statistic T(z) based on permutated samples z
    T_stat_temp = FUN(z, n1, ...)
    
    N_bigger = N_bigger + sum(T_stat_temp>=thres) 
  }
  
  return( N_bigger/N )
}

#if number of permutation is very large, need to divide; otherwise run out of memory
#this is the alternative way as the above one: do the parallel computing at this step:
crude_permutation_test2_large2 = function(x, n1, thres, N, seed=1, ncore, FUN=mean_diff, ...)
{
  n=length(x)
  n2=n-n1
  
  T_stat = NULL
  niter = N/1e5
  N_bigger=0
  
  set.seed(seed)
  
  registerDoParallel(cores=ncore)
  
  res = foreach(i=1:niter, .combine=c) %dorng%
  {
    #generate 1e6 permutated samples
    z = permutation_two_crude(x, n, nperm=1e5)
    
    #calculate the permutated statistic T(z) based on permutated samples z
    T_stat_temp = FUN(z, n1, ...)
    
    return( sum(T_stat_temp>=thres) )
  }
  
  return( sum(res)/N )
}