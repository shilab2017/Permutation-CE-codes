library(matrixStats)
library(sampling)

#########################################################################################
#this function calculates two-sample t statistic for unequal variances
#z need to be sorted as: the first n1 elements belong to group1; the last n2 elements belong to group2
t_statistic = function(z, n1)
{
  n=dim(z)[2]
  n2=n-n1
  
  group1=z[,1:n1]
  group2=z[,(n1+1):n]
  
  mu1 = rowMeans(group1)
  mu2 = rowMeans(group2)
  var1 = rowVars(group1)
  var2 = rowVars(group2)
  
  return( (mu1-mu2) / sqrt(var1/n1+var2/n2) )
}

#this function calculates difference of the mean between two groups
#z need to be sorted as: the first n1 elements belong to group1; the last n2 elements belong to group2
mean_diff = function(z, n1)
{
  n=dim(z)[2]
  n2=n-n1
  
  group1=z[,1:n1]
  group2=z[,(n1+1):n]
  
  mu1 = rowMeans(group1)
  mu2 = rowMeans(group2)
  
  return(mu1-mu2)
}

#this function is for the SAMC package of Yu et al, 2011
mean_diff_SAMC = function(data.input)
{
   x<-data.input$x
   y<-data.input$y
   return( mean(x) - mean(y) )
}

#################below are the functions related to the adaptive CE method
##########################################################################################
Rvals1 = function(k, W)
#calculate both the Rk and Rkj functions for the conditional Bernoulli distribution
#see method 1 of Chen and Liu 1997  
{
  n=length(W)
  TT=matrix(0, nrow=k, ncol=n+1)
  R=matrix(0, nrow=k+1, ncol=n+1)
  
  WW=matrix(W^rep(1:k, each=n),nrow=k, byrow=T)
  TT[,1] = rowSums(WW)
  TT[,2:(n+1)] = TT[,1]-WW
  
  R[1,]=rep(1, n+1)
  
  for(i in 1:k)
  {
    R[i+1,] = colSums(matrix((-1)^((1:i)+1)*TT[1:i,]*R[i:1,], nrow=i)) / i
  }
  
  return(c(R[k,2:(n+1)], R[k+1,1])) #return a vector: R(n-1,S\{1}),R(n-1,S\{2}),...,R(n-1,S\{N}),R(n,S)
  #return(list(Rk=R[k+1,1], Rkj=R[k,2:(N+1)]))
}

calculate_R_n_S = function(n, w)
#this is Method 2 for calculating R(n,S) as described in Chen and Liu 1997
{
  N=length(w)
  
  R=array(0, c(n, N))
  
  for(i in 1:(N-n+1)) { R[1,i]= sum(w[1:i]) }
  
  for(i in 2:n)
  {
    #print(i)
    for(j in i:(i+N-n))
    { 
      #print(j)
      R[i,j] = R[i,j-1] + w[j]*R[i-1,j-1]
    }
  }
  
  return(R) #Note: R[n,N] is R(n,S); R[n,N-1] is R(n-1,S\{N})
}

calculate_RR = function(n, w)
{
  N=length(w)
  RR=NA

  #first calculate R(n,S) and R(n-1,S\{N})
  R_n_S = calculate_R_n_S(n, w)
  RR[N+1] = R_n_S[n,N]
  RR[N] = R_n_S[n-1,N-1]
  
  for(i in 1:(N-1))
  {
    RR[i] = calculate_R_n_S(n-1, w[-i])[n-1, N-1]
  }
  
  return(RR) #return a vector: R(n-1,S\{1}),R(n-1,S\{2}),...,R(n-1,S\{N}),R(n,S)
}

permutation_two = function(n, q, nperm)
{
  res=array(0, c(nperm, n))
  
  for( i in 1:nperm)
  {
    res[i,] = UPMEsfromq(q)
  }
  
  return(res)
}


likelihood_condbern=function(d, k, W, Rk) #calculate the likelihood of the conditional Bernoulli dist.
{
  return(rowProds(t(W^t(d)))/Rk)
}

maximize_CE_function = function(S, d)
#S is the vector of weight; d is the 0/1 group indicator; w is the parameter
{
  M=dim(d)[1]
  N=dim(d)[2]
  n=sum(d[1,])
  
  x=colSums(S*d)
  
  xx=cbind(idx=1:N, x) #idx is the original index of x
  
  xx = xx[order(xx[,2]),] #sort x
  
  x_sort = xx[,2]
  
  w_start = x_sort / sum(S)
  w_old = rep(0, N)
  w_new = w_start
  iter=0
  
  while(max(abs(w_new-w_old)/(w_old+1e-9))>0.1)
  {
    w_old = w_new
    
    #R = Rvals1(n, w_old)
    R = calculate_RR(n, w_old)

    w_new = ( x_sort*R[N] ) / (sum(S)*R[1:N])

    iter = iter+1
    if(iter>20)
    {
      cat("Minimization of CE formular does not converge!\n")
      break;
    }
  }
  
  w_res = cbind(xx[,1], w_new)
  w_res = w_res[order(w_res[,1]),]
  
  #w needs to be re-scaled to make w[1] as 1. Otherwise, the model is un-identifiable
  return(w_res[,2]/w_res[1,2])
}

d_to_z = function(x, d, n1, n2) #Given the observed data (x) and partition matrix d, calculate the permutated data matrix z
{
  dd = as.vector(t(d))
  xx = rep(x,times=dim(d)[1])
  
  return( cbind( matrix(xx[dd==1], ncol=n1, byrow=T), matrix(xx[dd==0], ncol=n2, byrow=T) ) )
}

AIR2 = function(p0, p_start, x, n1, thres, N=1000, M=1e4, rho=0.1, max_iter=20, seed=1, FUN=mean_diff, ...)
{
  n=length(x)
  n2=n-n1
  
  #crude parameters - parameters under crude random permutation
  W0 = p0/(1-p0)
  Rk0 = calculate_R_n_S(n1, W0)[n1,n] #calculate Rk under crude ramdom permutation

  #start value - note these can be different from the crude paramters
  p=p_start
  W = p/(1-p)
  Rk = calculate_R_n_S(n1, W)[n1,n] #calculate Rk

  q = UPMEqfromw(W, n1) #calculate q

  gamma=0
  
  #keep the sequence of gamma
  #gamma_seq = NULL
  
  set.seed(seed)
  iter=0 #iteration number
  
  while(gamma<thres)
  {
    #generate N permutated samples according to the density f(Z;p)
    d = permutation_two(n, q, nperm=N) #d is a N*n matrix of 0/1 group partition indicators

    z = d_to_z(x, d, n1, n2)
    
    T_stat = FUN(z, n1, ...)
    
    #sort T, need to keep the index of the original T
    TT = cbind(idx=1:N, T_stat) #idx is the original index of T_stat 
    TT = TT[order(TT[,2]),] #sort T_stat
    eidx = ceiling(N*(1-rho)) #eidx is the index of N(1-rho) quantile of T
    gamma=TT[eidx,2] #set gamma_k = T[N(1-rho) quantile]
    
    #gamma_seq = c(gamma_seq, gamma)
    
    if(gamma>=thres) #if N(1-rho) quantile of T >= thres, set gamma_k to thres and shift the eidx
    {
      gamma=thres
      
      while(TT[eidx,2]>=gamma)
      {
        eidx = eidx-1
      }
      
      eidx = eidx+1
    }
    
    idx = TT[,1] #idx is the sorted index
    
    d_effective = d[idx[eidx:N],] #find those effective samples
    
    #calculate the likelihood ratio based on effective sample: Q = f(z;W0)/f(z;W)
    likhood_p0 = likelihood_condbern(d_effective, n1, W0, Rk0)
    likhood_p = likelihood_condbern(d_effective, n1, W, Rk)
    Q=likhood_p0/likhood_p #likelihood ratios:Q - a vector of length N
    
    #update the parameters W (P) by maximizing the CE formula
    W = maximize_CE_function(Q, d_effective) #update W
    
    p = W/(1+W) #update p
    
    Rk = calculate_R_n_S(n1, W)[n1,n] #update Rk
    q = UPMEqfromw(W, n1) #update q
    
    iter = iter+1
    if(iter>max_iter) 
    {
      cat("Model does not converge after maximum number of iterations!\n")
      break;
    }
  }
  
  #last step: estimating the p value using M permutated samples
  #generate M permutated samples according to the density f(Z;p)
  d = permutation_two(n, q, nperm=M) #d is a N*n matrix of 0/1 group partition indicators
  z = d_to_z(x, d, n1, n2)
  T_stat = FUN(z, n1, ...)
  
  #calculate the likelihood ratio: Q = f(z;p0)/f(z;pt)
  likhood_p0 = likelihood_condbern(d, n1, W0, Rk0)
  likhood_p = likelihood_condbern(d, n1, W, Rk)
  Q=likhood_p0/likhood_p #likelihood ratios:Q - a vector of length N
  
  u = sum((T_stat>=gamma)*Q)/M
  
  #return(list(u=u, p=p, w=W, gamma_seq=gamma_seq))
  return(c(u, iter))
}

######################################################################################
