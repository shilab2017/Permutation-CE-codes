###Table 1 compares the 3 methods for 20 vs.20 from two normal distributions
##the three methods are: crude permutation; AISP2 (originally neamed AIR2 as in these scripts) of our paper; SAMC of Yu et al, 2011

#Table 1: AISP2 and SAMC

rm(list=ls())

library(doParallel) #load the doParallel package to enable parallel computing with R
library(doRNG) #load the doRNG package to enable the results can be reproducible in parallel computing
#these packages work well with linux system, but have some problems with Windows system

library(EXPERT) #this package implement the SAMC algorithm of Yu et al,2011
#Downloaded from Dr.Kai Yu's website: https://dceg.cancer.gov/tools/analysis/expert
#version EXPERT_0.0.7.tar.gz for linux system

#load the script of AIR2 and other functions
sourceDir <- function(path, trace = TRUE, ...) {
  for (nm in list.files(path, pattern = "\\.[RrSsQq]$")) {
    if(trace) cat(nm,":")           
    source(file.path(path, nm), ...)
    if(trace) cat("\n")
  }
}

sourceDir('/users/yangshi/projects/resampling/script')
######################################################################################
n1=20
n2=20
n=n1+n2
mu=c(1,1.25,1.5)
N_repeat=100
ncore = detectCores()

x1 = array(0, c(length(mu), n1))
x2 = array(0, c(length(mu), n2))
x = array(0, c(length(mu), n))
thres=p.t_res=NA

for(i in 1:length(mu))
{ 
  set.seed(1)
  x1[i,]=rnorm(n=n1, mean=mu[i])
  x2[i,]=rnorm(n=n2)
  x[i,]=c(x1[i,], x2[i,])
  thres[i] = ( mean(x1[i,])-mean(x2[i,]) )
  
  #Also looked at the results of t test - for small p-values with finite samples size, t-test is different with permutation test
  #p.t_res[i] = t.test(x1[i,], x2[i,], alternative = 'greater', var.equal = T)$p.value
}

time_AIR2=time_SAMC=NULL

res_AIR2 = res_SAMC = matrix(0, nrow=length(mu), ncol=N_repeat)

p0=rep(0.5, n) #starting probabilities for the conditional Bernoulli distribution, which is 0.5

for(i in 1:length(mu)) #for different mu, run both AISP2 and SAMC
{

#AIR2
registerDoParallel(cores=ncore)
time=proc.time()
res_AIR2[i,] = foreach(j=1:N_repeat, .combine=c) %dorng%
{
  res1 = AIR2(p0, p_start=p0, x[i,], n1=n1, thres[i], N=2000, M=10000, rho=0.1, seed=j)
  return(res1)
}
time_AIR2 = rbind(time_AIR2, (proc.time()-time))

#SAMC
registerDoParallel(cores=ncore)

data.input = list(x=x1[i,], y=x2[i,])

mean.obs = mean_diff_SAMC(data.input)

time=proc.time()
res_SAMC[i,] = foreach(j=1:N_repeat, .combine=c) %dorng%
{
  #please see the manual of the SAMC package for the instructions of this function
  #note it only computes the two-sided p-value. Here we tested 1-sided p-value, so we divided by 2
  res2 = SAMC.adapt(data.input, mean.obs, t.start=0, n.iter.1=200000,
                    n.iter.2=1000000, n.region.1=101, n.region.2=301,
                    prop.change=0.05, gain.factor.t0=1000,
                    fun.test.statistic=mean_diff_SAMC, fun.proposal=proposal.permute.vector)$p.value/2
  return(res2)
}
time_SAMC = rbind(time_SAMC, (proc.time()-time))

##below also tested the SAMC program using the t-statistic to make sure it works - the t-statistic function is a build-in function in the package
#time=proc.time()
#data.input = list(x=x1[i,], y=x2[i,])

#t.obs = t.test.statistic(data.input)

#res_SAMC[i,] = foreach(j=1:N_repeat, .combine=c) %dorng%
#{
#  res3 = SAMC.adapt(data.input, t.obs, t.start=0, n.iter.1=200000,
#                    n.iter.2=1000000, n.region.1=101, n.region.2=301,
#                    prop.change=0.05, gain.factor.t0=1000,
#                    fun.test.statistic=t.test.statistic, fun.proposal=proposal.permute.vector)$p.value/2
#  return(res3)
#}
#time_SAMC = rbind(time_SAMC, (proc.time()-time))

}

save.image('/users/yangshi/projects/resampling/AIR2_SAMC_20vs20.RData')
