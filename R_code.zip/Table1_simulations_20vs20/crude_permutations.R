###Table 1 compares the 3 methods for 20 vs.20 from two normal distributions
##the three methods are: crude permutation; AISP2 of Shi et al; SAMC of Yu et al, 2011

#Table 1: crude permutations

#1.1
#This is Crude II, difference of means (mu) is 1, number of permuted samples is 1e7 

rm(list=ls())
library(doParallel) #load the doParallel package to enable parallel computing with R
library(doRNG) #load the doRNG package to enable the results can be reproducible in parallel computing
#these packages work well with linux system, but have some problems with Windows system

#load the script of crude permutations and AIR2 
source('/users/yangshi/projects/resampling/script/crude2.R')
source('/users/yangshi/projects/resampling/script/AIR2.R')

n1=20
n2=20
n=n1+n2
mu=1
N_repeat=100
N_crude=1e7
ncore = detectCores()

set.seed(1)
x1=rnorm(n=n1, mean=mu)
x2=rnorm(n=n2)
x=c(x1, x2)
thres = mean(x1)-mean(x2)
  
#crude permutation
registerDoParallel(cores=ncore)
time=proc.time()
res_crude = foreach(j=1:N_repeat, .combine=c) %dorng%
{
 res1 = crude_permutation_test2_large(x, n1=n1, thres, N=N_crude, seed=j)
 return(res1)
}
time_crude = proc.time()-time
filename='/users/yangshi/projects/resampling/crude20vs20/crude_mu1_N1e7.RData'
save.image(filename)

##############################################################################################

#1.2
#This is Crude II, difference of means (mu) is 1.25, number of permuted samples is 1e8
rm(list=ls())
library(doParallel) #load the doParallel package to enable parallel computing with R
library(doRNG) #load the doRNG package to enable the results can be reproducible in parallel computing
#these packages work well with linux system, but have some problems with Windows system

#load the script of crude permutations and AIR2 
source('/users/yangshi/projects/resampling/script/crude2.R')
source('/users/yangshi/projects/resampling/script/AIR2.R')

n1=20
n2=20
n=n1+n2
mu=1.25
N_repeat=100
N_crude=1e8
ncore = detectCores()

set.seed(1)
x1=rnorm(n=n1, mean=mu)
x2=rnorm(n=n2)
x=c(x1, x2)
thres = mean(x1)-mean(x2)

#crude permutation
registerDoParallel(cores=ncore)
time=proc.time()
res_crude = foreach(j=1:N_repeat, .combine=c) %dorng%
{
  res1 = crude_permutation_test2_large(x, n1=n1, thres, N=N_crude, seed=j)
  return(res1)
}
time_crude = proc.time()-time
filename='/users/yangshi/projects/resampling/crude20vs20/crude_mu125_N1e8.RData'
save.image(filename)

##############################################################################################

#1.3
#This is Crude II, difference of means (mu) is 1.5, number of permuted samples is 1e9
rm(list=ls())
library(doParallel) #load the doParallel package to enable parallel computing with R
library(doRNG) #load the doRNG package to enable the results can be reproducible in parallel computing
#these packages work well with linux system, but have some problems with Windows system

#load the script of crude permutations and AIR2 
source('/users/yangshi/projects/resampling/script/crude2.R')
source('/users/yangshi/projects/resampling/script/AIR2.R')

n1=20
n2=20
n=n1+n2
mu=1.5
N_repeat=100
N_crude=1e9
ncore = detectCores()

set.seed(1)
x1=rnorm(n=n1, mean=mu)
x2=rnorm(n=n2)
x=c(x1, x2)
thres = mean(x1)-mean(x2)

#crude permutation
registerDoParallel(cores=ncore)
time=proc.time()
res_crude = foreach(j=1:N_repeat, .combine=c) %dorng%
{
  res1 = crude_permutation_test2_large(x, n1=n1, thres, N=N_crude, seed=j)
  return(res1)
}
time_crude = proc.time()-time
filename='/users/yangshi/projects/resampling/crude20vs20/crude_mu15_N1e9.RData'
save.image(filename)

##############################################################################################

#1.4
#This is Crude I, difference of means (mu) is 1, number of permuted samples is 1e8

rm(list=ls())
library(doParallel) #load the doParallel package to enable parallel computing with R
library(doRNG) #load the doRNG package to enable the results can be reproducible in parallel computing
#these packages work well with linux system, but have some problems with Windows system

#load the script of crude permutations and AIR2 
source('/users/yangshi/projects/resampling/script/crude2.R')
source('/users/yangshi/projects/resampling/script/AIR2.R')

n1=20
n2=20
n=n1+n2
mu=1
N_repeat=100
N_crude=1e8
ncore = detectCores()

set.seed(1)
x1=rnorm(n=n1, mean=mu)
x2=rnorm(n=n2)
x=c(x1, x2)
thres = mean(x1)-mean(x2)

#crude permutation
registerDoParallel(cores=ncore)
time=proc.time()
res_crude = foreach(j=1:N_repeat, .combine=c) %dorng%
{
  res1 = crude_permutation_test2_large(x, n1=n1, thres, N=N_crude, seed=j)
  return(res1)
}
time_crude = proc.time()-time
filename='/users/yangshi/projects/resampling/crude20vs20/crude_mu1_N1e8.RData'
save.image(filename)

##############################################################################################

#1.5
#This is Crude II, difference of means (mu) is 1.25, number of permuted samples is 1e9
rm(list=ls())
library(doParallel) #load the doParallel package to enable parallel computing with R
library(doRNG) #load the doRNG package to enable the results can be reproducible in parallel computing
#these packages work well with linux system, but have some problems with Windows system

#load the script of crude permutations and AIR2 
source('/users/yangshi/projects/resampling/script/crude2.R')
source('/users/yangshi/projects/resampling/script/AIR2.R')

n1=20
n2=20
n=n1+n2
mu=1.25
N_repeat=100
N_crude=1e9
ncore = detectCores()

set.seed(1)
x1=rnorm(n=n1, mean=mu)
x2=rnorm(n=n2)
x=c(x1, x2)
thres = mean(x1)-mean(x2)

#crude permutation
registerDoParallel(cores=ncore)
time=proc.time()
res_crude = foreach(j=1:N_repeat, .combine=c) %dorng%
{
  res1 = crude_permutation_test2_large(x, n1=n1, thres, N=N_crude, seed=j)
  return(res1)
}
time_crude = proc.time()-time
filename='/users/yangshi/projects/resampling/crude20vs20/crude_mu125_N1e9.RData'
save.image(filename)

##############################################################################################

#1.6
#This is Crude II, difference of means (mu) is 1.5, number of permuted samples is 1e10
rm(list=ls())
library(doParallel) #load the doParallel package to enable parallel computing with R
library(doRNG) #load the doRNG package to enable the results can be reproducible in parallel computing
#these packages work well with linux system, but have some problems with Windows system

#load the script of crude permutations and AIR2 
source('/users/yangshi/projects/resampling/script/crude2.R')
source('/users/yangshi/projects/resampling/script/AIR2.R')

n1=20
n2=20
n=n1+n2
mu=1.5
N_repeat=100 #in our simulations, we split the 100 repetition on two clusters. Otherwise, it takes too long.
N_crude=1e10
ncore = detectCores()

set.seed(1)
x1=rnorm(n=n1, mean=mu)
x2=rnorm(n=n2)
x=c(x1, x2)
thres = mean(x1)-mean(x2)

#crude permutation
registerDoParallel(cores=ncore)
time=proc.time()
res_crude = foreach(j=1:N_repeat, .combine=c) %dorng%
{
  res1 = crude_permutation_test2_large(x, n1=n1, thres, N=N_crude, seed=j)
  return(res1)
}
time_crude = proc.time()-time
filename='/users/yangshi/projects/resampling/crude20vs20/crude_mu15_N1e10.RData'
save.image(filename)