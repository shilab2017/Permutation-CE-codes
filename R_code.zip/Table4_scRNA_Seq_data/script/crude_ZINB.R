library(matrixStats)
library(pscl)

#this function calculates the LRT statistic from the zero-inflated negative binomial model
#z is a matrix containing the permutated data and need to be sorted as: the first n1 elements belong to group1; the last n2 elements belong to group2
calculate_LRT_stat = function(z,n1)
{
  res = NA
  condition = as.factor(c(rep(1, n1), rep(2,dim(z)[2]-n1)))
  for(i in 1:(dim(z)[1]))
  {
    count = z[i,]
    m1 = zeroinfl(count ~ condition | condition, dist = "negbin")
    m0 = update(m1, . ~ 1)
    res[i] = 2 * (logLik(m1) - logLik(m0))
  }
  return(res)
}

#'generate permutated samples: x is oberserved data, n is sample size, nperm is number of permutated samples
permutation_two_crude = function(x, n, nperm)
{
  res=array(0, c(nperm, n))
  
  for( i in 1:nperm)
  {
    res[i,] = sample(x, size=n)
  }
  
  return(res)
}

#if number of permutation is very large, need to divide by groups; otherwise run out of memory
crude_permutation_test2_large = function(x, n1, thres, N, seed=1, FUN=modified_t_statistic, ...)
{
  n=length(x)
  n2=n-n1
  
  T_stat = NULL
  niter = N/1e5
  N_bigger=0
  
  set.seed(seed)
  
  for(i in 1:niter)
  {
    #generate 1e6 permutated samples
    z = permutation_two_crude(x, n, nperm=1e5)
    
    #calculate the permutated statistic T(z) based on permutated samples z
    T_stat_temp = FUN(z, n1, ...)
    
    N_bigger = N_bigger + sum(T_stat_temp>=thres) 
  }
  
  return( N_bigger/N )
}
