rm(list=ls())

#install the packages scde: version 1.99.1 was used in this script
source("https://bioconductor.org/biocLite.R")
biocLite("scde")

library(scde) #load the package

##The the following chunck of codes was taken from the website of scde package (http://hms-dbmi.github.io/scde/diffexp.html), which tests differential expression of the ES/MEF scRNA dataset
###############################################################################################################
#load example dataset
data(es.mef.small)

# factor determining cell types
sg = factor(gsub("(MEF|ESC).*", "\\1", colnames(es.mef.small)), levels = c("ESC", "MEF"))

# the group factor should be named accordingly
names(sg) = colnames(es.mef.small)  
table(sg)

# clean up the dataset
cd = clean.counts(es.mef.small, min.lib.size=1000, min.reads = 1, min.detected = 1)

# EVALUATION NOT NEEDED
# calculate models
o.ifm = scde.error.models(counts = cd, groups = sg, n.cores = 8, threshold.segmentation = TRUE, save.crossfit.plots = FALSE, save.model.plots = FALSE, verbose = 1)

data(o.ifm)
head(o.ifm)

# filter out cells that don't show positive correlation with
# the expected expression magnitudes (very poor fits)
valid.cells <- o.ifm$corr.a > 0
table(valid.cells)

o.ifm <- o.ifm[valid.cells, ]

# estimate gene expression prior
o.prior <- scde.expression.prior(models = o.ifm, counts = cd, length.out = 400, show.plot = FALSE)

# define two groups of cells
groups <- factor(gsub("(MEF|ESC).*", "\\1", rownames(o.ifm)), levels  =  c("ESC", "MEF"))
names(groups) <- row.names(o.ifm)
# run differential expression tests on all genes.
ediff <- scde.expression.difference(o.ifm, cd, o.prior, groups  =  groups, n.randomizations  =  100, n.cores  =  1, verbose  =  1)
###############################################################################################################

library(doParallel) #load the doParallel package to enable parallel computing with R
library(doRNG) #load the doRNG package to enable the results can be reproducible in parallel computing
#these packages work well with linux system, but have some problems with Windows system

library(pscl) #this package can fit the zero-inflated negative binomial model


#Extract the top ten differentially expressed genes
up = rownames(head(ediff[order(ediff$Z, decreasing  =  TRUE), ], n=10))

#Extract the read count matrix for the top ten differentially expressed genes
exp_dat10 = es.mef.small[row.names(es.mef.small) %in% top10_gene,]

condition = as.factor(c(rep(1, 20), rep(2,20)))

#calculate the observed likelihood ratio statistics
LRT = p_value = NA
for(i in 1:dim(exp_dat10)[1])
{
  count = as.vector(as.matrix(exp_dat10[i,]))

  m1 = zeroinfl(count ~ condition | condition, dist = "negbin")
  m0 = update(m1, . ~ 1)
  LRT[i] = 2 * (logLik(m1) - logLik(m0))
  
  #We also looked at the p-values from the asymptotic chi_square (df=2) distribution
  #p_value[i] = pchisq(2 * (logLik(m1) - logLik(m0)), df = 2, lower.tail=FALSE)
}

#top10_gene = rownames(top10_count)
#res = data.frame(top10_gene, p_value)
#res_new = res[order(res$p_value),]

#this function calculates the LRT statistic from the zero-inflated negative binomial model
#z is a matrix containing the permutated data and need to be sorted as: the first n1 elements belong to group1; the last n2 elements belong to group2
calculate_LRT_stat = function(z,n1)
{
  res = NA
  condition = as.factor(c(rep(1, n1), rep(2,dim(z)[2]-n1)))
  for(i in 1:(dim(z)[1]))
  {
    count = z[i,]
    m1 = zeroinfl(count ~ condition | condition, dist = "negbin")
    m0 = update(m1, . ~ 1)
    res[i] = 2 * (logLik(m1) - logLik(m0))
  }
  return(res)
}

source('/media/shyboy/software/GoogleDrive/projects/resampling/single_cell/script/crude2.R')
source('/media/shyboy/software/GoogleDrive/projects/resampling/single_cell/script/AIR2.R')

dat = as.vector(as.matrix(exp_dat10[1,]))

#the crude permutation
###############################################################################################################
N_crude = 1e8 #number of permutated samples
n_gene = 10 #number of genes to be tested
n1=20 #number of samples of the 1st group
N_repeat = 100 #number of repetations
n_core = 50 #here we use 50 cores of the cluster

result_crude = array(0, c(n_gene, N_repeat))

#crude permutation
time=proc.time()
for(i in 1:n_gene)
{
  x = as.vector(as.matrix(exp_dat10[i,]))
  thres = LRT[i]
  
  registerDoParallel(cores=n_core)
  
  result_crude[i,] = foreach(j = 1:N_repeat, .combine=c) %dorng%
  {
    #runs the crude permutations
    return(crude_permutation_test2_large(x=x, n1=n1, thres=thres, N=N_crude, seed=j))
  }
}
time_crude = time-proc.time()

save.image('/media/shyboy/software/GoogleDrive/projects/resampling/single_cell/crude_ZINB.RData')
###############################################################################################################

#runs AISP2 (originally neamed AIR2 as below) to scRNA-Seq dataset
#we run this part in a separate script to crude permutations - simply replace the chunck of the crude permutations with this part

n=40 #number of samples
n1=20 #number of samples of the 1st group
p0=rep(0.5, n) #starting probabilities for the conditional Bernoulli distribution with crude permutations, which is 0.5
n_gene = 10 #number of the top differentially expressed probesets reported in Kang et al, 2010
N_repeat = 100 #number of repetations
n_core = 50 #here we use 50 cores of the cluster

result_AIR2 = array(0, c(n_gene,N_repeat))

#AIR2
time=proc.time()
for(i in 1:n_gene)
{
  x = as.vector(as.matrix(exp_dat10[i,]))
  thres = LRT[i]
  
  registerDoParallel(cores=n_core)
  result_AIR2[i,] = foreach(j = 1:N_repeat, .combine=c) %dorng%
  {
    #runs the AISP2 algorithm
    return(AIR2(p0=p0, p_start=p0, x=x, n1=n1, thres=thres, N=4000, M=10000, rho=0.1, seed=j))
  }
}

time_AIR2 = time-proc.time()

save.image('/media/shyboy/software/GoogleDrive/projects/resampling/single_cell/AIR2_ZINB.RData')
###############################################################################################################
