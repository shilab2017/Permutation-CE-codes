library(matrixStats)
#this function calculates the modified two-sample t statistic as in the SAMR package
#z need to be sorted as: the first n1 elements belong to group1; the last n2 elements belong to group2
#s0 is the small constant added to the denominator as computed in samr
modified_t_statistic = function(z, n1, s0)
{
  n=dim(z)[2]
  n2=n-n1
  
  group1=z[,1:n1]
  group2=z[,(n1+1):n]
  
  mu1 = rowMeans(group1)
  mu2 = rowMeans(group2)
  var1 = rowVars(group1)
  var2 = rowVars(group2)
  
  sd = sqrt( ((n1 - 1)*var1 + (n2 - 1)*var2) * (1/n1+1/n2)/(n1+n2-2) )
  
  return( (mu1-mu2)/(sd+s0) )
}

#'generate permutated samples: x is oberserved data, n is sample size, nperm is number of permutated samples
permutation_two_crude = function(x, n, nperm)
{
  res=array(0, c(nperm, n))
  
  for( i in 1:nperm)
  {
    res[i,] = sample(x, size=n)
  }
  
  return(res)
}

#if number of permutation is very large, need to divide by groups; otherwise run out of memory
crude_permutation_test2_large = function(x, n1, thres, N, seed=1, FUN=modified_t_statistic, ...)
{
  n=length(x)
  n2=n-n1
  
  T_stat = NULL
  niter = N/1e5
  N_bigger=0
  
  set.seed(seed)
  
  for(i in 1:niter)
  {
    #generate 1e6 permutated samples
    z = permutation_two_crude(x, n, nperm=1e5)
    
    #calculate the permutated statistic T(z) based on permutated samples z
    T_stat_temp = FUN(z, n1, ...)
    
    N_bigger = N_bigger + sum(T_stat_temp>=thres) 
  }
  
  return( N_bigger/N )
}
