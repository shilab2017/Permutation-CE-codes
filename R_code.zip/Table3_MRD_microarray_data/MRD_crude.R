#Table3 demonstrates our algorithm AISP2 to the MRD microarray dataset, and compares it with the crude permutation procedure
#This script runs the crude permutation procedure to the MRD microarray dataset
rm(list=ls())

#load the MRD data
#this microarray dataset is published in Kang, H., et al.(2010) Gene expression classifiers for relapse-free survival and minimal residual disease improve risk classification and outcome prediction in pediatric B-precursor acute lymphoblastic leukemia, Blood, 115, 1394-1405.
#available at Gene Expression Omnibus (http://www.ncbi.nih.gov/geo) under accession number GSE11877 (https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE11877)
#for questions regarding the dataset itself, please contact the second author of the paper, Dr. Huining Kang (HuKang@salud.unm.edu)
load('/users/yangshi/projects/MRD/data/MRD_dat_to_use.RData')

#load the script that includes the function for calculating the modified t-statistic in the SAMR package
source('/users/yangshi/projects/MRD/script/crude_modified_t.R')

library(doParallel) #load the doParallel package to enable parallel computing with R
library(doRNG) #load the doRNG package to enable the results can be reproducible in parallel computing
#these packages work well with linux system, but have some problems with Windows system

N_crude = 1e8 #number of permutated samples
n_gene = 23 #number of the top differentially expressed probesets reported in Kang et al, 2010
N_repeat = 100 #number of repetations
n_core = 50 #here we use 50 cores of the cluster

result_crude = array(0, c(n_gene, N_repeat))

#crude permutation
time=proc.time()
for(i in 1:n_gene)
{
  x = exp_dat[i,] #exp_dat is a subset of the whole microarray dataset that contains the expression levels of the top 23 differentially expressed probesets
  thres = modified_t_stat[i]
  n1 = n1_vec[i]
  
  registerDoParallel(cores=n_core)
  
  result_crude[i,] = foreach(j = 1:N_repeat, .combine=c) %dorng%
  {
    #runs the crude permutations
    return(crude_permutation_test2_large(x=x, n1=n1, thres=thres, N=N_crude, seed=j, s0=s0))
  }
}
time_crude = time-proc.time()

save.image('/users/yangshi/projects/MRD/crude/MRD_crude.RData')